////////////////////////////////////////////////////
// Shop by Department page: 
// - find all department header and links incl. hidden links
// - launch each link page, get page title and url, then back or close if on new tab; total takes about 20~30 mins to complete.
// - output result to excel file. Currently www.amazon.ca has 20 department groups and 183 links.
// By:  Julianne X.
///////////////////////////////////////////////////

package tests;

import java.util.regex.Pattern;
import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import Functions.My_Functions;

public class DepartmentsLinksTest extends My_Functions {
 // private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  
  @Before
  public void setUp() throws Exception {
	/*	
		driver = getDriver("firefox");  // user defined Functions.My_Functions - input "chrome" or "firefox", else default to microsoft edge on windows 10
	    baseUrl = "https://www.amazon.ca";
	    driver.manage().deleteAllCookies();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	 */  // move driver setup to @Test so that test can also be called to run in /'TestSuites
  }

  @Test
  public void testAllDepartmentLink() throws Exception {
		driver = getDriver("chrome");  // user defined Functions.My_Functions - input "chrome" or "firefox", else default to microsoft edge on windows 10
	    baseUrl = "https://www.amazon.ca";
	    driver.manage().deleteAllCookies();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	    driver.get(baseUrl + "/");
    
    try {
         assertEquals("Shop by", driver.findElement(By.cssSelector("#nav-link-shopall > span.nav-line-1")).getText());
         assertEquals("Department", driver.findElement(By.cssSelector("#nav-link-shopall > span.nav-line-2")).getText());
      // assertEquals("Shop by \nDepartment", driver.findElement(By.id("nav-link-shopall")).getText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("nav-link-shopall")).click(); // Shop by Department top nav
    try {
	     
    	WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(ExpectedConditions.titleContains("Amazon.ca - Earth's Biggest Selection"));
    }
    catch(Exception e) {
        System.out.println("Timeout exceeded Loading All Department Links Page");
        //driver.close();
    }

	int tdN=1;
	int divN = 1;
	int liN = 1;
	int r = 0;
	int hCount = 0;
	int lCount = 0;
    
	File file = new File("./DataPool/TestOutput.xls"); 

	WritableWorkbook wb = Workbook.createWorkbook(file);
	WritableSheet sht = wb.createSheet("DepartmentLinks", 0);
	sht.addCell(new Label(0, 0,  "Notes"));
	sht.addCell(new Label(1, 0, "Dept_HeaderLabel"));
	sht.addCell(new Label(2, 0, "Dept_LinkLabel"));
	sht.addCell(new Label(3, 0, "Locator_XPATH"));
	sht.addCell(new Label(4, 0, "Link_PageTitle"));
	sht.addCell(new Label(5, 0, "Link_url"));
	
   	String xpathStr = ".//*[@id='shopAllLinks']/tbody/tr/td[" + String.valueOf(tdN) + "]/div["+ String.valueOf(divN)+ "]/h2";
    
    while (isElementPresent(By.xpath(xpathStr)))
    { 
       	while  (isElementPresent(By.xpath(xpathStr)))
	    {
	    	String Department =  driver.findElement(By.xpath(xpathStr)).getText();
	     	r = r+1;
	    	sht.addCell(new Label(3, r,  xpathStr));
	    	sht.addCell(new Label(1, r,  Department));
	    	//System.out.println(Department + " |--- " + xpathStr);
	    	xpathStr = ".//*[@id='shopAllLinks']/tbody/tr/td[" + String.valueOf(tdN) + "]/div["+ String.valueOf(divN) + "]/ul/li[" + String.valueOf(liN) + "]/a";
	    	
	    	
	    	
	    	while (isElementPresent(By.xpath(xpathStr)))
		    {
		    	Department =  driver.findElement(By.xpath(xpathStr)).getText();
		    	r = r+1;
		    	sht.addCell(new Label(3, r,  xpathStr));
		    	sht.addCell(new Label(2, r,  Department));
		    	//System.out.println(Department + " | " + xpathStr);
		    	
		    	if (Department.trim().isEmpty()){
		    		sht.addCell(new Label(0, r,  "Hidden link"));
		    		System.out.println( "hidden link    ==== " + xpathStr);
		    	}
		    	else {	
			    	driver.findElement(By.xpath(xpathStr)).click();
			    	new WebDriverWait(driver, 30).until(
			    			webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));

			    	//System.out.println(Department + " | " + xpathStr  +" +++=============++++   "+ driver.getWindowHandles().size(););
		    		if (driver.getWindowHandles().size() > 1) {	      
		    	    //get window handlers as list
		    	      ArrayList<String> browserTabs = new ArrayList<String> (driver.getWindowHandles());
		    	      //switch to new tab
		    	      driver.switchTo().window(browserTabs.get(1));
		    	     
		    	      //wait for the new tab title 
			          while (driver.getTitle().isEmpty()) {
			        	     Thread.sleep(100);
                      }
		    	      try {
		    	     
		    	          String title = driver.getTitle();
		    	          sht.addCell(new Label(0, r,  "New Tab"));
		    	          sht.addCell(new Label(4, r,  title));
		    	          String url = driver.getCurrentUrl();
		   		    	  sht.addCell(new Label(5, r,  url));
				    	//System.out.println(title);
				     	//System.out.println(Department + " | " + xpathStr + " ------------------------------------------    " + driver.getTitle().toString());
				   		driver.close();
		    	      }
		    	      catch(Exception e) {
		    	          System.out.println("Timeout exceeded when getting the new tab page title.");
		    	      }

	   	              // back to main tab
			    	  driver.switchTo().window(browserTabs.get(0));

		    	 	}
		    	 	else{
		    	 	   String title = driver.getTitle();
		    	       sht.addCell(new Label(4, r,  title));
		    	       String url = driver.getCurrentUrl();
		    	       sht.addCell(new Label(5, r,  url));
		    		 //System.out.println(Department + " | " + xpathStr + " ------------------------------------------    " + driver.getTitle().toString());
		    	       driver.navigate().back();
		    	 	}
		    	}
		    	lCount = lCount+1;
		    	liN += 1;
		    	xpathStr = ".//*[@id='shopAllLinks']/tbody/tr/td[" + String.valueOf(tdN) + "]/div["+ String.valueOf(divN) + "]/ul/li[" + String.valueOf(liN) + "]/a";
		    }
	    	hCount = hCount + 1;
		    divN += 1; 
		    liN = 1;
		    xpathStr = ".//*[@id='shopAllLinks']/tbody/tr/td[" + String.valueOf(tdN) + "]/div["+ String.valueOf(divN)+ "]/h2";
	    }
    	tdN += 1; 
    	divN = 1; 
	    liN = 1;
	    xpathStr = ".//*[@id='shopAllLinks']/tbody/tr/td[" + String.valueOf(tdN) + "]/div["+ String.valueOf(divN)+ "]/h2";
    }

    sht.addCell(new Label(0, r+1, "Department Header count: " + hCount + " - Deparment Link count " + lCount));
    sht.addCell(new Label(0, r+2, "Shop by Department page URL: " + driver.getCurrentUrl()));
    sht.addCell(new Label(0, r+3, "Shop by Department page Title: " + driver.getTitle()));
    wb.write();
	wb.close();
	System.out.println("Workbook is created; Depart Header Count: " + hCount + ", Depart Link Count: " + lCount);
	driver.quit();
  }

  @After
  public void tearDown() throws Exception {
   // driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }


  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
