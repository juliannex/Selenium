////////////////////////////////////////////////////
// funtions (getDriver,SignIn, SignOut, DeleteCart, SearchAdd, ..) etc.
//
// By:  Julianne X.
///////////////////////////////////////////////////
package Functions;


import jxl.*;
import jxl.read.biff.BiffException;
import org.openqa.selenium.JavascriptExecutor;

import static org.junit.Assert.assertEquals;
import java.util.Properties;
import java.lang.Double;
import java.text.DecimalFormat;
import java.io.File;
import java.io.FileInputStream;
import java.util.Locale;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.util.List;


public class My_Functions {
	public static Properties prop;
	public static WebDriver driver;
	
	public static WebDriver getDriver (String browser)
	{
		 //  WebDriver driver;
		   
		   switch (browser.toLowerCase()) {
           case "firefox":
        	   		System.setProperty("webdriver.gecko.driver", "C:\\Selenium\\workspace\\MyShoppingProject\\Lib\\geckodriver.exe");  // path of geckodriver.exe
        	   		driver = new FirefoxDriver();
        	   		driver.manage().deleteAllCookies();
        	   		break;
           case "chrome":
		   	   		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\workspace\\MyShoppingProject\\Lib\\chromedriver.exe"); // path of chromedriver.exe
		   	   		driver = new ChromeDriver();
		   	   		driver.manage().deleteAllCookies();
		   	   		break;
        // default to Microsoft Edge on Windows 10       
           default:  											
	        	   	DesiredCapabilities capability = DesiredCapabilities.edge();
	        	   	capability.setBrowserName("MicrosoftEdge");
	        	    capability.setPlatform(Platform.WIN10);
	      			System.setProperty("webdriver.edge.driver","C:\\Selenium\\workspace\\MyShoppingProject\\Lib\\MicrosoftWebDriver.exe"); //path of MicrosoftWebDriver.exe
	      			driver = new EdgeDriver(); 
	      			break;
		   }
		   return driver;
	}
	
	public static WebDriver getDriver ()
	{
		 //  WebDriver driver;
		   
		   // default to Microsoft Edge on Windows 10       
	        	   	DesiredCapabilities capability = DesiredCapabilities.edge();
	        	/*
	        	   	capability.setCapability("nativeEvents", false);
	        	   	capability.setCapability("unexpectedAlertBehaviour", "accept");
	        	   	capability.setCapability("ignoreProtectedModeSettings", true);
	        	   	capability.setCapability("disable-popup-blocking", true);
	        	   	capability.setCapability("enablePersistentHover", true);
	        	   	capability.setCapability("ignoreZoomSetting", true);
	        	 */  	
	        	   	capability.setBrowserName("MicrosoftEdge");
	        	    capability.setPlatform(Platform.WIN10);
	      			System.setProperty("webdriver.edge.driver","C:\\Selenium\\workspace\\MyShoppingProject\\Lib\\MicrosoftWebDriver.exe"); //path of MicrosoftWebDriver.exe
	      			driver = new EdgeDriver(); 
 
		   return driver;
	}
	
	public void SignIn(String Usr, String Pwd) throws Exception
	{
	    driver.findElement(By.id("nav-link-yourAccount")).click();
	    driver.findElement(By.id("ap_email")).clear();
	    driver.findElement(By.id("ap_email")).sendKeys(Usr);
	    driver.findElement(By.id("continue")).isEnabled();
	    driver.findElement(By.id("continue")).click();
	    driver.findElement(By.id("ap_password")).clear();
	    driver.findElement(By.id("ap_password")).sendKeys(Pwd);
	    Thread.sleep(1000);
	    driver.findElement(By.id("signInSubmit")).click();
	//    Thread.sleep(1000);
	}
	
	
	public void SignOut2() throws Exception
	{   
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf( driver.findElement(By.id("nav-link-yourAccount"))));
		WebElement ele = driver.findElement(By.id("nav-link-yourAccount"));
		Actions action = new Actions(driver);
	    action.moveToElement(ele).build().perform();  // Microsoft edge driver not working 
	    new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf( driver.findElement(By.linkText("Sign Out"))));
	    Thread.sleep(1000);
	    driver.findElement(By.linkText("Sign Out")).click();
	    //  driver.findElement(By.id("nav-item-signout-sa")).click();
	}
	
	public void SignOut1() throws Exception
	{
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf( driver.findElement(By.id("nav-link-yourAccount"))));
		WebElement ele = driver.findElement(By.id("nav-link-yourAccount"));
		Actions action;
		action = new Actions(driver).clickAndHold(ele);             // Microsoft edge driver works with right click but not movetoElement nor clickAndHold
		 action.build().perform();
	    new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf( driver.findElement(By.linkText("Sign Out"))));
	    Thread.sleep(1000);
	    driver.findElement(By.linkText("Sign Out")).click();
	}
		
	public void SignOut() throws Exception  
	{   
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf( driver.findElement(By.id("nav-link-yourAccount"))));
		WebElement ele = driver.findElement(By.id("nav-link-yourAccount"));
		JavascriptExecutor js = (JavascriptExecutor) driver;    // Microsoft edge driver not working either
		js.executeScript("var clickEvent = document.createEvent('MouseEvents');clickEvent.initEvent('mouseover', true, true); arguments[0].dispatchEvent(clickEvent);", ele);
	    driver.findElement(By.linkText("Sign Out")).click();
	 //   driver.findElement(By.id("nav-link-yourAccount"));
	}
	
	public int DeleteCart() throws Exception
	{
		int count = Integer.valueOf(driver.findElement(By.id("nav-cart-count")).getText().trim());
	//	driver.findElement(By.id("nav-cart")).click();
		if( count != 0)
		{
			driver.findElement(By.id("nav-cart")).click();
			if (isElementPresent(By.xpath(".//*[@id='activeCartViewForm']/div[2]/div[1]/div[4]/div/div[1]/div/div/div[2]/div/span[1]/span/input")))
			{
				driver.findElement(By.xpath(".//*[@id='activeCartViewForm']/div[2]/div/div[4]/div/div[1]/div/div/div[2]/div/span[1]/span/input")).click();
				Thread.sleep(1000);
				driver.findElement(By.id("nav-cart")).click();
				while (isElementPresent(By.xpath(".//*[@id='activeCartViewForm']/div[2]/div[1]/div[4]/div/div[1]/div/div/div[2]/div/span[1]/span/input")))
				{
					driver.findElement(By.xpath(".//*[@id='activeCartViewForm']/div[2]/div[1]/div[4]/div/div[1]/div/div/div[2]/div/span[1]/span/input")).click();;
					Thread.sleep(1000);
					driver.findElement(By.id("nav-cart")).click();
			    }
			}
			else // (isElementPresent(By.xpath(".//*[@id='activeCartViewForm']/div[2]/div/div[4]/div/div[1]/div/div/div[2]/div/span[1]/span/input")))
			{
				driver.findElement(By.xpath(".//*[@id='activeCartViewForm']/div[2]/div/div[4]/div/div[1]/div/div/div[2]/div/span[1]/span/input")).click();
			}
	}
	
	 //    Thread.sleep(1000);
		System.out.println(count + " items deleted");
	    return count;
	}

	public double SearchAdd(String Item) throws InterruptedException
	{
		 String unitPrice = null; 
		 String currency ="CDN$";
   //driver.get(baseUrl + "/");
		driver.findElement(By.id("twotabsearchtextbox")).clear();
	    driver.findElement(By.id("twotabsearchtextbox")).sendKeys(Item);
	    driver.findElement(By.cssSelector("input.nav-input")).click();
	    Thread.sleep(1000);

	    String xpathStr = "//img[@alt=\"" + Item + "\"]";
		System.out.println(xpathStr);
	    if (isElementPresent(By.xpath(xpathStr)))
	    {
	    	driver.findElement(By.xpath(xpathStr)).click();
		    if (isElementPresent(By.id("native_dropdown_selected_size_name")))
		    {
		  //  new Select(driver.findElement(By.id("native_dropdown_selected_size_name"))).selectByVisibleText("Shoe Size 4 - 10");
		    
		    	driver.findElement(By.id("native_dropdown_selected_size_name")).click();
		    	driver.findElement(By.xpath(".//*[@id='native_size_name_0']")).click();
		    	WebDriverWait wait = new WebDriverWait(driver, 30);
		        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("quantity")));
		        Thread.sleep(1000);
		       	if (isElementPresent(By.id("priceblock_ourprice")))
		    	{
		    		unitPrice = driver.findElement(By.id("priceblock_ourprice")).getText().replaceAll("CDN$", "").trim();
		    		try{
			    		driver.findElement(By.id("add-to-cart-button")).click();
			    	}
			    	catch (Exception e){
			    		System.out.println("Item can't be directly added to Cart!");
			    		e.printStackTrace();
			    	}
		    	}
		    	else if (isElementPresent(By.id("priceblock_saleprice")))
		    	{
		    		unitPrice = driver.findElement(By.id("priceblock_saleprice")).getText().replaceAll("CDN$", "").trim();
		    		try{
			    		driver.findElement(By.id("add-to-cart-button")).click();
			    	}
			    	catch (Exception e){
			    		System.out.println("Item can't be directly added to Cart!");
			    		e.printStackTrace();
			    	}
		    	}
		    }
		    else
		    {
		    	if (isElementPresent(By.id("priceblock_ourprice")))
		    	{
		    		unitPrice = driver.findElement(By.id("priceblock_ourprice")).getText().replaceAll("CDN$", "").trim();
		    		try{
			    		driver.findElement(By.id("add-to-cart-button")).click();
			    	}
			    	catch (Exception e){
			    		System.out.println("Item can't be directly added to Cart!");
			    		e.printStackTrace();
			    	}
		    	}
		    	else if (isElementPresent(By.id("priceblock_saleprice")))
		    	{
		    		unitPrice = driver.findElement(By.id("priceblock_saleprice")).getText().replaceAll("CDN$", "").trim();
		    		try{
			    		driver.findElement(By.id("add-to-cart-button")).click();
			    	}
			    	catch (Exception e){
			    		System.out.println("Item can't be directly added to Cart!");
			    		e.printStackTrace();
			    	}
		    	}   	
		    	System.out.println("["+ Item + "] has no Size.");
		    }
		    
			 Thread.sleep(1000);
		 	 return Double.valueOf(unitPrice.replace(currency, "").trim());
	    }
		else
	    {
	    	System.out.println("[" + Item +"] not found.");
	    	return 0.00; 
	    }
	}
	
	public String SearchAdd(String Item, int Qty) throws InterruptedException
	{
		String unitPrice = null;
		//
		// to be implemented
		//
		return unitPrice;
  	}
	
	public int CartCount() throws Exception
	{
        return Integer.valueOf(driver.findElement(By.id("nav-cart-count")).getText().trim());
    }
	
	public double CartSubtotal() throws Exception
	{
		String count = driver.findElement(By.id("nav-cart-count")).getText().trim();
		String currency = "CDN$";
		String subtotal = null;
		driver.findElement(By.id("nav-cart")).click();
		if (count == "0")
		{
		    assertEquals("Your Shopping Cart is empty.", driver.findElement(By.xpath(".//*[@id='sc-active-cart']/div/h1")).getText().trim());
		}
		else
		{
			//count = driver.findElement(By.id("nav-cart-count")).getText().trim();
		    subtotal = driver.findElement(By.xpath(".//*[@id='sc-subtotal-amount-activecart']/span")).getText().trim();
	        assertEquals(currency, subtotal.substring(0, 4));
	        subtotal = subtotal.replace(currency, "").trim();
    	}  	
		// System.out.println(subtotal);
		
        return roundTwoDecimals(subtotal);
    }

	
	
	// Function for if element is clickable
	public static boolean isClickable(WebElement el, WebDriver driver) 
	{
	      try{
	          WebDriverWait wait = new WebDriverWait(driver, 10);
	          wait.until(ExpectedConditions.elementToBeClickable(el));
	          return true;
	      }
	      catch (Exception e){
	          return false;
	      }
	}
	
	//Function to dynamically wait for element presence
	public void WaitForElementPresent(WebDriver driver , By by, int iTimeOut) throws InterruptedException
	{
		int iTotal = 0;
		int iSleepTime = 2000;
		try
		{
		while(iTotal < iTimeOut)
		{
			List<WebElement> oWebElements = driver.findElements(by);
			if(oWebElements.size()>0)
				return;
			else
			{
				
					Thread.sleep(iSleepTime);
					iTotal = iTotal + iSleepTime;
					System.out.println(String.format("Waited for %d milliseconds.[%s]", iTotal, by));          
				
				
			}
		}
		}
		catch (Exception e)
		{
		  e.printStackTrace();
		}
		
	}
	
	
	 private boolean isElementPresent(By by) 
	 {
		    try {
		      driver.findElement(by);
		      return true;
		    } catch (NoSuchElementException e) {
		      return false;
		    }
	 }
	 
	 public double roundTwoDecimals(double d)
	 {
         DecimalFormat twoDForm = new DecimalFormat("#.##");
         return Double.valueOf(twoDForm.format(d));
	 }
	 
	 public double roundTwoDecimals(String s)
	 {
		 double d = Double.valueOf(s);
         DecimalFormat twoDForm = new DecimalFormat("#.##");
         return Double.valueOf(twoDForm.format(d));
	 }
//verify function(s)
	 public static void main(String [ ] args) {
		WebDriver driver = getDriver("firefox");
		driver.get("https://www.amazon.ca");
		getDriver("chrome").get("https://www.amazon.ca");
		getDriver().get("https://www.amazon.ca");
	}

}
